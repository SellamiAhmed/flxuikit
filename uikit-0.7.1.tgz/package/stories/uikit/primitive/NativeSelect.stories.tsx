
import type { Meta, StoryObj, StoryFn } from '@storybook/react'
import { NativeSelect } from '@flex/uikit'

type Story = StoryObj<typeof NativeSelect>

const decorator = (Story: StoryFn) => {
  return (
    <div style={{ margin: '3em' }}>
      <Story />
    </div>
  )
}

const meta: Meta<typeof NativeSelect> = {
  title: 'Primitive/NativeSelect',
  component: NativeSelect,
  decorators: [decorator],
  tags: ['autodocs'],
  parameters: {},
}
export default meta

// More on interaction testing: https://storybook.js.org/docs/react/writing-tests/interaction-testing
export const Primary: Story = {
  render: () => (<NativeSelect></NativeSelect>),
  args: {}
}
