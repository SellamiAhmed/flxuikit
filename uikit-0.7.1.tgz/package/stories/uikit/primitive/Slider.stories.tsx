
import type { Meta, StoryObj, StoryFn } from '@storybook/react'
import { Slider } from '@flex/uikit'

type Story = StoryObj<typeof Slider>

const decorator = (Story: StoryFn) => {
  return (
    <div style={{ margin: '3em' }}>
      <Story />
    </div>
  )
}

const meta: Meta<typeof Slider> = {
  title: 'Primitive/Slider',
  component: Slider,
  decorators: [decorator],
  tags: ['autodocs'],
  parameters: {},
}
export default meta

// More on interaction testing: https://storybook.js.org/docs/react/writing-tests/interaction-testing
export const Primary: Story = {
  render: () => (<Slider></Slider>),
  args: {}
}
