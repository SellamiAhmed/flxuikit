
import type { Meta, StoryObj, StoryFn } from '@storybook/react'
import { PasswordInput } from '@flex/uikit'

type Story = StoryObj<typeof PasswordInput>

const decorator = (Story: StoryFn) => {
  return (
    <div style={{ margin: '3em' }}>
      <Story />
    </div>
  )
}

const meta: Meta<typeof PasswordInput> = {
  title: 'Primitive/PasswordInput',
  component: PasswordInput,
  decorators: [decorator],
  tags: ['autodocs'],
  parameters: {},
}
export default meta

// More on interaction testing: https://storybook.js.org/docs/react/writing-tests/interaction-testing
export const Primary: Story = {
  render: () => (<PasswordInput></PasswordInput>),
  args: {}
}
