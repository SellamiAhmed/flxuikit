
import type { Meta, StoryObj, StoryFn } from '@storybook/react'
import { List } from '@flex/uikit'

type Story = StoryObj<typeof List>

const decorator = (Story: StoryFn) => {
  return (
    <div style={{ margin: '3em' }}>
      <Story />
    </div>
  )
}

const meta: Meta<typeof List> = {
  title: 'Primitive/List',
  component: List,
  decorators: [decorator],
  tags: ['autodocs'],
  parameters: {},
}
export default meta

// More on interaction testing: https://storybook.js.org/docs/react/writing-tests/interaction-testing
export const Primary: Story = {
  render: () => (<List></List>),
  args: {}
}
