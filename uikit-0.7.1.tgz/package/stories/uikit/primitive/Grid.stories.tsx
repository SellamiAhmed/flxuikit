
import type { Meta, StoryObj, StoryFn } from '@storybook/react'
import { Grid } from '@flex/uikit'

type Story = StoryObj<typeof Grid>

const decorator = (Story: StoryFn) => {
  return (
    <div style={{ margin: '3em' }}>
      <Story />
    </div>
  )
}

const meta: Meta<typeof Grid> = {
  title: 'Primitive/Grid',
  component: Grid,
  decorators: [decorator],
  tags: ['autodocs'],
  parameters: {},
}
export default meta

// More on interaction testing: https://storybook.js.org/docs/react/writing-tests/interaction-testing
export const Primary: Story = {
  render: () => (<Grid></Grid>),
  args: {}
}
